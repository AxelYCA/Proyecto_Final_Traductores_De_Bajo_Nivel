%include "macros.inc"

global _sumar, _restar, _multiplicar, _dividir
global _contarCaracteres, _convertirMayusculas

SECTION .text

; --------------------------------------------------
; SUMAR
; Recibe dos numeros desde C y devuelve su suma.
; Los valores llegan en [ebp+8] y [ebp+12].
; --------------------------------------------------
_sumar:
    SAVE
    mov eax, [ebp+8]      ; primer numero
    mov ebx, [ebp+12]     ; segundo numero
    add eax, ebx          ; suma en eax
    RESTORE
    ret

; --------------------------------------------------
; RESTAR
; Resta b a a. Igual que arriba, se toman desde la pila.
; --------------------------------------------------
_restar:
    SAVE
    mov eax, [ebp+8]
    mov ebx, [ebp+12]
    sub eax, ebx
    RESTORE
    ret

; --------------------------------------------------
; MULTIPLICAR
; Multiplica los dos valores recibidos.
; El resultado queda en eax automaticamente.
; --------------------------------------------------
_multiplicar:
    SAVE
    mov eax, [ebp+8]
    mov ebx, [ebp+12]
    imul ebx
    RESTORE
    ret

; --------------------------------------------------
; DIVIDIR
; Division con verificacion para evitar dividir entre cero.
; Si el divisor es cero, se devuelve 0.
; --------------------------------------------------
_dividir:
    SAVE
    mov eax, [ebp+8]      ; dividendo
    mov ebx, [ebp+12]     ; divisor

    cmp ebx, 0            ; si el divisor es cero
    je .err               ; si sí, regresar 0

    cdq                   ; extender signo para la division
    idiv ebx              ; dividir eax / ebx
    jmp .fin

.err:
    mov eax, 0            ; valor por defecto

.fin:
    RESTORE
    ret

; --------------------------------------------------
; CONTAR CARACTERES
; Recorre la cadena hasta encontrar el 0 final.
; Va sumando en ecx el total de caracteres.
; --------------------------------------------------
_contarCaracteres:
    SAVE
    mov esi, [ebp+8]      ; puntero a la cadena
    xor ecx, ecx          ; contador en 0

.loop:
    mov al, [esi]         ; obtener el caracter actual
    cmp al, 0             ; fin de cadena
    je .fin

    inc ecx               ; sumar al conteo
    inc esi               ; avanzar
    jmp .loop

.fin:
    mov eax, ecx          ; devolver el total
    RESTORE
    ret

; --------------------------------------------------
; CONVERTIR A MAYUSCULAS
; Recorre la cadena y convierte cada letra de 'a' a 'z'
; utilizando la diferencia de 32 en ASCII.
; --------------------------------------------------
_convertirMayusculas:
    SAVE
    mov esi, [ebp+8]

.loop2:
    mov al, [esi]         ; obtener caracter
    cmp al, 0             ; fin de cadena
    je .fin2

    cmp al, 'a'           ; menor a 'a' → no tocar
    jl .next
    cmp al, 'z'           ; mayor a 'z' → no tocar
    jg .next

    sub al, 32            ; convertir a mayúscula
    mov [esi], al

.next:
    inc esi
    jmp .loop2

.fin2:
    RESTORE
    ret
