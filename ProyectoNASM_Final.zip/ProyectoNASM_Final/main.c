#include <stdio.h>
#include <string.h>

// Declaracion de las funciones que tenemos en el modulo de NASM.
extern int sumar(int a, int b);
extern int restar(int a, int b);
extern int multiplicar(int a, int b);
extern int dividir(int a, int b);
extern int contarCaracteres(char *cadena);
extern void convertirMayusculas(char *cadena);

int main() {
    int opcion;
    int a, b, resultado;
    char texto[200];

    do {
        // Menu principal
        printf("\n MENU MINI INTERPRETE C + NASM \n");
        printf("1. Sumar\n");
        printf("2. Restar\n");
        printf("3. Multiplicar\n");
        printf("4. Dividir\n");
        printf("5. Contar caracteres\n");
        printf("6. Convertir a MAYUSCULAS\n");
        printf("7. Salir\n");
        printf("Selecciona opcion: ");
        scanf("%d", &opcion);

        switch(opcion) {
            
            case 1:
                // Captura de numeros y llama a la función NASM
                printf("Ingresa A: "); scanf("%d", &a);
                printf("Ingresa B: "); scanf("%d", &b);
                resultado = sumar(a, b);
                printf("Resultado = %d\n", resultado);
                break;

            case 2:
                // Llamada a la funcion restar en NASM
                printf("Ingresa A: "); scanf("%d", &a);
                printf("Ingresa B: "); scanf("%d", &b);
                resultado = restar(a, b);
                printf("Resultado = %d\n", resultado);
                break;

            case 3:
                // Llamada a multiplicar en NASM
                printf("Ingresa A: "); scanf("%d", &a);
                printf("Ingresa B: "); scanf("%d", &b);
                resultado = multiplicar(a, b);
                printf("Resultado = %d\n", resultado);
                break;

            case 4:
                // Llamada a dividir, con manejo de cero dentro del NASM
                printf("Ingresa A: "); scanf("%d", &a);
                printf("Ingresa B: "); scanf("%d", &b);
                resultado = dividir(a, b);
                printf("Resultado = %d\n", resultado);
                break;

            case 5:
                // Envio de una cadena para contar sus caracteres
                printf("Ingresa texto: ");
                scanf(" %[^\n]", texto);
                resultado = contarCaracteres(texto);
                printf("Total caracteres = %d\n", resultado);
                break;

            case 6:
                // Conversion de una cadena a mayúsculas mediante NASM
                printf("Ingresa texto: ");
                scanf(" %[^\n]", texto);
                convertirMayusculas(texto);
                printf("MAYUSCULAS = %s\n", texto);
                break;

            case 7:
                // Salida del programa
                printf("Saliendo...\n");
                break;

            default:
                // Opcion no valida
                printf("Opcion invalida.\n");
        }

    } while(opcion != 7);

    return 0;
}